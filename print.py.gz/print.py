#!/usr/bin/env python
import os
print("hola mundo");
print("linea2");
#os.makedirs("eee");
